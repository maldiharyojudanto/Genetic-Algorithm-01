// This library is free and distributed under
// Mozilla Public License Version 2.0.

#define OPENGA_EXTERN_LOCAL_VARS
#include "openGA.hpp"
#include "header.hpp"

void main2()
{
	run_test(false,false,0,"run-test-2");
}
